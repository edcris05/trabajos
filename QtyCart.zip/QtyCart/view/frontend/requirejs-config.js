var config = {
    map: {
        '*': {
            // This code helps us to override the knockout HTML template file.
            'Magento_Checkout/template/minicart/item/default.html': 'Trabajos_QtyCart/template/minicart/item/default.html',
            // The bellow codes help us to override the JS files
            'sidebar': 'Trabajos_QtyCart/js/sidebar',
            'Magento_Checkout/js/view/minicart': 'Trabajos_QtyCart/js/view/minicart'
        }
    }
};

