var config = {
    map: {
        "*": {
            "carousel-main-news": "Trabajos_News/js/carousel-main-news"
        }
    }
}